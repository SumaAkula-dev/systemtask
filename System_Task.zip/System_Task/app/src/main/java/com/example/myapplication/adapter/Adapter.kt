package com.example.myapplication.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.databinding.RecycleviewItemBinding
import com.example.myapplication.model.VehicleType

class Adapter(private val vehicleTypes: List<VehicleType>) :
    RecyclerView.Adapter<Adapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = RecycleviewItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)

    }

    override fun getItemCount(): Int {
        return vehicleTypes.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.name.text = vehicleTypes[position].text
    }

    inner class ViewHolder(val binding: RecycleviewItemBinding) : RecyclerView.ViewHolder(binding.root)

}