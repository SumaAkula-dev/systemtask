package com.example.myapplication

import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.adapter.Adapter
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.databinding.ActivityMainBinding
import com.example.myapplication.model.RequestData
import com.example.myapplication.viewModel.ViewModel
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : AppCompatActivity() {


    private lateinit var binding: ActivityMainBinding

    private lateinit var viewModel: ViewModel

    private lateinit var vehicleTypeListAdapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel = ViewModelProvider(this)[ViewModel::class.java]
        setOTP()
        vehicleTypeListAdapter = Adapter(emptyList())
        liveData()

    }

    private val editTexts: List<EditText> by lazy {
        (1..6).map { index ->
            findViewById<EditText>(
                resources.getIdentifier(
                    "otp_field$index",
                    "id",
                    packageName
                )
            )
        }
    }

    private fun setOTP() {
        editTexts.forEachIndexed { index, editText ->
            editText.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    charSequence: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    charSequence: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {
                    if (count == 1 && index < editTexts.lastIndex) {
                        editTexts[index + 1].requestFocus()
                    }
                }

                override fun afterTextChanged(editable: Editable?) {}
            })

            editText.setOnKeyListener { _, keyCode, keyEvent ->
                if (keyCode == KeyEvent.KEYCODE_DEL && keyEvent.action == KeyEvent.ACTION_DOWN && index > 0) {
                    editTexts[index - 1].requestFocus()
                }
                false
            }
        }
    }

    private fun liveData() {
        viewModel.vehicleDetails.observe(this) { vehicleDetails ->
            vehicleTypeListAdapter = Adapter(vehicleDetails.vehicle_type)
            binding.rv.adapter = vehicleTypeListAdapter

            setUpSpinner(binding.fuelType, vehicleDetails.fuel_type.map { it.text }, "fuel type") {
                // Handle selected fuel type
            }

            setUpSpinner(
                binding.manufactureYear,
                vehicleDetails.manufacture_year.map { it.text },
                "manufacture year"
            ) {
                // Handle selected manufacture year
            }

            setUpSpinner(
                binding.vehicleCapacity,
                vehicleDetails.vehicle_capacity.map { it.text },
                "vehicle capacity"
            ) {
                // Handle selected vehicle capacity
            }

            setUpSpinner(
                binding.vehicle,
                vehicleDetails.vehicle_make.map { it.text },
                "vehicle making company"
            ) {
                // Handle selected vehicle make
            }
            setUpSpinner(
                binding.modelName,
                listOf<String>("Grand Vitara", "MPV", "Sedan", "Hvac", "Lorry"),
                "model name"
            ) {
                //Handle selected model name
            }

            setUpSpinner(
                binding.drive,
                listOf<String>("Driver", "Helper", "Collector", "Backup Driver"),
                "drive role"
            ) {
                //Handle selected drive role
            }
        }

        binding.button.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.own -> {
                    val selectedValue = "OWN"
                }

                R.id.contractor -> {
                    val selectedValue = "Contractor"
                }
            }
        }

        binding.iemi.setOnClickListener {
            when {
                ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    android.Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED -> {
                    showCamera()
                }

                shouldShowRequestPermissionRationale(android.Manifest.permission.CAMERA) -> {
                    Toast.makeText(
                        this@MainActivity,
                        "Camera Permission Required",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                else -> {
                    requestingPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                }
            }
        }

        val requestBody = RequestData(11, 1007, "9889897789", 3476)
        viewModel.fetchData(requestBody)

    }

    // Function to set up a spinner with common configuration
    private fun setUpSpinner(
        autoCompleteTextView: AutoCompleteTextView,
        data: List<String>,
        prompt: String,
        onItemSelected: (String) -> Unit
    ) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, data).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        autoCompleteTextView.apply {
            setAdapter(adapter)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parentView: AdapterView<*>?,
                    selectedItemView: View?,
                    position: Int,
                    id: Long
                ) {
                    if (position == AdapterView.INVALID_POSITION) {
                        showToast("Please select $prompt")
                    } else {
                        onItemSelected(parentView?.getItemAtPosition(position).toString())
                    }
                }

                override fun onNothingSelected(parentView: AdapterView<*>?) {}
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
    }

    private fun showCamera() {
        val option = ScanOptions().apply {
            setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            setPrompt("Scan QR Code")
            setCameraId(0)
            setBeepEnabled(true)
            setBarcodeImageEnabled(true)
            setOrientationLocked(false)
        }
        scanLauncher.launch(option)
    }

    private val requestingPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                showCamera()
            } else {
                Toast.makeText(this@MainActivity, "Does  Support Camera", Toast.LENGTH_SHORT)
                    .show()
            }
        }

    private val scanLauncher = registerForActivityResult(ScanContract()) {
        if (it.contents == null) {
            Toast.makeText(this, "canceled", Toast.LENGTH_SHORT).show()
        } else {
            binding.iemi.setText(it.contents)
        }
    }
}