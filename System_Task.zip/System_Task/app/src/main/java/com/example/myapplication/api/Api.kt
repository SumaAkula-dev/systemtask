package com.example.myapplication.api

import com.example.myapplication.model.RequestData
import com.example.myapplication.model.vehicleInfo
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface Api {
    @Headers("Content-Type: application/json")
    @POST("jhsmobileapi/mobile/configure/v1/task")
    suspend fun fetchData(@Body request: RequestData): Response<vehicleInfo>
}