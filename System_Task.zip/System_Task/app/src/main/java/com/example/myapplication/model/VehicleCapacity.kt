package com.example.myapplication.model

data class VehicleCapacity(
    val images: String,
    val text: String,
    val value: Int
)