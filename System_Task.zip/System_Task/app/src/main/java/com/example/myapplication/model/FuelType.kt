package com.example.myapplication.model

data class FuelType(
    val images: String,
    val text: String,
    val value: Int
)