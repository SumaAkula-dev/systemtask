package com.example.myapplication.model


data class RequestData(
    val clientid: Int,
    val enterprise_code: Int,
    val mno: String,
    val passcode: Int
)