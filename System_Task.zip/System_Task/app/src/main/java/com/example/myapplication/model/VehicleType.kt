package com.example.myapplication.model

data class VehicleType(
    val images: String,
    val text: String,
    val value: Int
)