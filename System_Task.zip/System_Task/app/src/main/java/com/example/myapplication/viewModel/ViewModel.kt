package com.example.myapplication.viewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.myapplication.api.RetrofitClient
import com.example.myapplication.model.RequestData
import com.example.myapplication.model.vehicleInfo
import kotlinx.coroutines.launch
import retrofit2.Response

class ViewModel : ViewModel() {

    var retrofit = RetrofitClient.api

    private val _vehicleDetails = MutableLiveData<vehicleInfo>()
    val vehicleDetails:LiveData<vehicleInfo> = _vehicleDetails

    private val _error = MutableLiveData<String>()

    fun fetchData(request: RequestData) {

        viewModelScope.launch {
            try {
                val response: Response<vehicleInfo> = retrofit.fetchData(request)
                if (response.isSuccessful) {
                    Log.d("success", "api data is  ${response.body()}")
                    _vehicleDetails.value = response.body()
                } else {
                    _error.value = "Error: ${response.code()}"
                    Log.d("error", " 1 ${response.code()}")
                }
            } catch (e: Exception) {
                _error.value = "Network error: ${e.message}"
                Log.d("message", " 2 ${e.message}")

            }
        }
    }

}