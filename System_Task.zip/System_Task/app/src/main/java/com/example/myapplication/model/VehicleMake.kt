package com.example.myapplication.model

data class VehicleMake(
    val images: String,
    val text: String,
    val value: Int
)